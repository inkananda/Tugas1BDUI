<?php include 'header.php'; ?>

<?php 
	
$errh = $errw = "";
$height = $weight = "";
$bmipass = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
	if (empty($_POST['height'])) {
		$errh = "<span style = 'color:red; font-size:14px; display:block'> *Data Tinggi Diperlukan </span>";
			} else {
				$height = validation($_POST['height']);
			}

	if (empty($_POST['weight'])) {
		$errw = "<span style = 'color:red; font-size:14px; display:block'> *Data Berat Diperlukan </span>";
			} else {
				$weight = validation($_POST['weight']);
			}	

			if (empty($_POST['height'] && $_POST['weight'])) {
				echo "";
			} else {
				$bmi = ($weight / ($height * $height ) * 10000);
				$bmipass = $bmi;
			}

		}

function validation($data) {
	$data = trim($data);
	$data = stripcslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

?>

	<h2>BMI Calculator</h2>
		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
			<div class="bagian1">
				<span>
					Height :
				</span>
				<input type="text" name="height" autocomplete="off" placeholder="Centimeter"><?php echo $errh; ?>
			</div>
			<div class="bagian2">
				<span>
					Weight :
				</span>
				<input type="text" name="weight" autocomplete="off" placeholder="Kilogram"> <?php echo $errw; ?>
			</div>
			<div class="submit">
				<input type="submit" name="submit" value="Check BMI">
				<input type="reset" value="Refresh">
			</div>
		</form>

<?php
    error_reporting(0);
        echo "<span class='pass'>Hasil BMI : ". number_format($bmipass , 2) ."</span>";
    if (isset($_POST['submit'])){
        if ($bmipass >= 13.6 && $bmipass <= 18.5) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px ;margin-right:50px'>Berat badan anda rendah. Anda perlu menambah berat badan.</span>";?>
            <?php
        } elseif ($bmipass > 18.5 && $bmipass < 24.9) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px;margin-right:50px'> Standar kesehatan yang baik.</span>";?>
            <?php
        } elseif ($bmipass > 25 && $bmipass < 29.9) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px;margin-right:50px'> Kelebihan berat badan. Anda perlu olahraga untuk mengurangi kelebihan berat badan.</span>";?>
            <?php
        } elseif ($bmipass > 30 && $bmipass < 34.9) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px;margin-right:50px'> Anda masuk dalam obesitas tahap pertama. Penting untuk memilih makanan yang sehat dan berolahraga.</span>";?>
           <?php
        } elseif ($bmipass > 35 && $bmipass < 39.9) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px;margin-right:50px'>Anda masuk dalam obesitas tahap kedua. Diperlukan diet dan berolahraga.</span>";?>
            <?php
        } elseif ($bmipass >= 40) {
            echo "<span style='color:#00203FFF; display:block; margin-top:5px;margin-right:50px'> Kelebihan lemak.<b style='color:#ed4337'>Takun akan terjadi kematian</b>. Anda memerlukan konsultasi ke dokter.</span>";?>
            <?php
        }
    } else {
        echo "";
    }
?>

<?php include 'footer.php'; ?>